package com.example.StudentApi.repository.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.entity.Student;
import com.example.StudentApi.exceptions.StudentException;
import com.example.StudentApi.repository.StudentInterface;


@Repository
public class StudentImplementation implements StudentInterface{

	
	
	private static final String INSERTSTUDENT = "INSERT INTO student (student_id, first_name, last_name, mobile_number, email_id)"
			+ " VALUES (?,?,?,?,?)";
	private static final String INSERTSTUDENTPROJECTS = "insert into student_project values(?,?)";
//	private static final String LEFTJOINSTUDENT = "SELECT * FROM student LEFT OUTER JOIN project ON student.project_list = project.project_id and student_id=?";
	private static final String FINDBYID = "SELECT * FROM student WHERE	student_id = ?";
	private static final String COUNTROWS = "SELECT COUNT(*) FROM student WHERE student_id = ?";
	
	private static final String PROJECTS = "select * from project join student_project on project.project_id = student_project.project_id "
			+ "where student_project.student_id = ?";
	
	private static final String PROJECTSCOUNT = "select count(*) from project join student_project on project.project_id = student_project.project_id "
			+ "where student_project.student_id = ?";
	
	private static final String FINDALLSTUDENTS = "SELECT * FROM student"; 
	
	
	
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public int save(Student student) {
		
		int countRows = jdbcTemplate.queryForObject(COUNTROWS, Integer.class, student.getStudentId());
		
		 if(countRows > 0)
			 throw new StudentException("Student already exists. Please enter new Student");
		 else {
			 return jdbcTemplate.update(INSERTSTUDENT,
				student.getStudentId(), student.getFirstName(), student.getLastName(), 
				student.getMobileNumber(), student.getEmailId()); 
		 }
	}

		
	@Override
	public Optional<Student> findById(int studentid){
		
		//getting exception error
//		int countRows = jdbcTemplate.queryForObject(COUNTROWS, Integer.class, studentid);
//		
//		
//		if(countRows > 0 ) {
//			
//			return jdbcTemplate.queryForObject(FINDBYID,
//					BeanPropertyRowMapper.newInstance(Student.class), studentid);
//			}
//		else {
//			throw new StudentNotPresentException("Student does not exists. Please enter valid student id");
//		}
		
		try {
				Student student =  jdbcTemplate.queryForObject(FINDBYID,
						BeanPropertyRowMapper.newInstance(Student.class), studentid);

				return Optional.of(student);
 
		}catch(EmptyResultDataAccessException p) {
			return Optional.empty();
		}
		
	}
	
	
	@Override
	public List<Student> findAll() {

		return jdbcTemplate.query( FINDALLSTUDENTS,
				BeanPropertyRowMapper.newInstance(Student.class));
	}


	@Override
	public List<Project> projectList(int studentId) {
		
		return jdbcTemplate.query(PROJECTS, BeanPropertyRowMapper.newInstance(Project.class),
				studentId);
	}


	@Override
	public int insertStudentProject(int studentId, int projectId) {
		
		//getting exception + msg
		int projectCount = jdbcTemplate.queryForObject(PROJECTSCOUNT, Integer.class, studentId);
		
		if(projectCount < 3)
			return jdbcTemplate.update(INSERTSTUDENTPROJECTS, studentId, projectId);
		else
			throw new StudentException("maximum 3 projects allowed");
		
		}

}
