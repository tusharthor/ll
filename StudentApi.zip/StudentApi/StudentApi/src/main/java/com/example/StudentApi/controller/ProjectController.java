package com.example.StudentApi.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.entity.Student;
import com.example.StudentApi.exceptions.ProjectException;
import com.example.StudentApi.repository.ProjectInterface;

@RestController
public class ProjectController {
	
	@Autowired
	ProjectInterface projectInterface;
	
	
	@GetMapping("/projects")
	public List<Project> getAllProjects(){
		return projectInterface.findAll();
	}

	
	@PostMapping("/project/insert")
	public String insertProject(@RequestBody Project project) {
		
		try {
			projectInterface.save(new Project(project.getProjectId(), project.getProjectName(), project.getDurationInDays(),
					project.getStartDate(), project.getEndDate()));
			
			return "Project Inserted";
		}catch(Exception e) {
			return e.getMessage();
		}
	}
	
	@GetMapping("/project/{projectId}")
	public Optional<Project> getProjectById(@PathVariable int projectId) {
		return projectInterface.findById(projectId);
	}
	
	@PutMapping("/project/update/{projectId}")
	public String updateByIdWithDurationDays(@PathVariable int projectId, @RequestBody Project project){
		
		try {
			projectInterface.updateProject(projectId, new Project(project.getProjectId(), project.getProjectName(), project.getDurationInDays(),
					project.getStartDate(), project.getEndDate()));
			
			return "Records Updated";
			
		}catch(Exception e) {
			return e.getMessage();
		}
	}
	
	@GetMapping("/projectStudents/{projectId}")
	public List<Student> projectStudents(@PathVariable int projectId){
		return projectInterface.studentListBasedOnProject(projectId);
	}
	
	@PostMapping("/projectStudents/insert/{projectId} - {studentId}")
	public String insertProjectStudents(@PathVariable int projectId, @PathVariable int studentId) {
		
		try {
			projectInterface.insertProjectStudent(projectId, studentId);
			return "Student added for project";
		}catch(ProjectException e) {
			return e.getMessage();
		}
	}
	
	
	
	
	
}
