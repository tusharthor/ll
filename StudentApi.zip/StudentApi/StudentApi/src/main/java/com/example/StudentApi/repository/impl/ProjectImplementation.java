package com.example.StudentApi.repository.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.exceptions.ProjectException;
import com.example.StudentApi.repository.ProjectInterface;


@Repository
public class ProjectImplementation implements ProjectInterface {

	private static final String INSERTPROJECT = "INSERT INTO project VALUES (?,?,?,?,?)";
	private static final String FINDBYID = "SELECT * FROM project WHERE	project_id = ?";
	private static final String FINDALLPROJECTS = "SELECT * FROM project"; 
	private static final String COUNTROWS = "select count(*) from project where project_id = ?";
	private static final String UPDATEDURATION = "UPDATE project set duration_in_days = ? WHERE project_id = ?";
	private static final String GETDURATIONDAYS = "SELECT duration_in_days from project where project_id = ?";
	private static final String DELETEPROJECT = "DELETE FROM project WHERE project_id = ?";
	private static final String AUTODELETE = "delete from student_project where project_id = ?";
//	private 
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public int save(Project project)  {
		
		int countRows =  jdbcTemplate.queryForObject(COUNTROWS, Integer.class, project.getProjectId());
		
		 if(countRows > 0)
			 throw new ProjectException("Project already exists. Please enter new project");
		 else {
			 
			 return  jdbcTemplate.update(INSERTPROJECT, 
					project.getProjectId(), project.getDurationInDays(),
					project.getEndDate(), project.getProjectName(), project.getStartDate());
		 }
		
	}

	
	@Override
	public Optional<Project> findById(int projectid) {
		
		try {
			Project project =  jdbcTemplate.queryForObject(FINDBYID,
					BeanPropertyRowMapper.newInstance(Project.class), projectid);

				return Optional.of(project);							//add logic for valid projectid
		}catch(EmptyResultDataAccessException e) {
			return Optional.empty();
		}
		
	}

	
	@Override
	public List<Project> findAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query( FINDALLPROJECTS,
				BeanPropertyRowMapper.newInstance(Project.class));
	}


	@Override
	public int updateProject(int projectId, Project project) {
		
		int countRows =  jdbcTemplate.queryForObject(COUNTROWS, Integer.class, projectId);
		
		 if(countRows > 0) {	//means project is present
			 
			 int currentDays = jdbcTemplate.queryForObject(GETDURATIONDAYS, Integer.class, projectId);
			 
			 int returnUpdatedData = jdbcTemplate.update(UPDATEDURATION, project.getDurationInDays(),project.getProjectId());
		
			 if(project.getDurationInDays() > currentDays)
				 return jdbcTemplate.update(AUTODELETE, projectId);
			 else
				 return returnUpdatedData;
		 }
		 else {
			 
			 throw new ProjectException("Please enter valid project");

		 }
		
	}

}
