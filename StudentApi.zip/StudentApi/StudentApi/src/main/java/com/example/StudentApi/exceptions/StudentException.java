package com.example.StudentApi.exceptions;

public class StudentException extends RuntimeException{

	public StudentException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

	}
