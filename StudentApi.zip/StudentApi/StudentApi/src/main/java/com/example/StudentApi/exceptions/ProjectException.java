package com.example.StudentApi.exceptions;

public class ProjectException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProjectException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
