package com.example.StudentApi.entity;

import java.util.*;



public class Student {
	
	private int studentId;
	private String firstName;
	private String lastName;
	private long mobileNumber; //BigInteger mobileNumber;
	
	private String emailId;
	

	List<Project> listOfProjectId = new ArrayList<>();
	

	public Student() {}

	public Student(int studentId, String firstName, String lastName, long mobileNumber, String emailId) {
		super();
		this.studentId = studentId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
//		this.listOfProjectId = projectList;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public List<Project> getProjectList() {
		return listOfProjectId;
	}

	public void setProjectList(List<Project> projectList) {
		this.listOfProjectId = projectList;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", mobileNumber=" + mobileNumber + ", emailId=" + emailId + "]";
	}
	
	
}

