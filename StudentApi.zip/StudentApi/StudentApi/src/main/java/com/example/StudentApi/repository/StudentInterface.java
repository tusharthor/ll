package com.example.StudentApi.repository;

import java.util.List;
import java.util.Optional;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.entity.Student;

public interface StudentInterface {

	int save(Student student) throws Exception;
	
	Optional<Student> findById(int studentId) throws Exception;
	
	List<Student> findAll();
	
	int insertStudentProject(int studentId, int projectId);
	
	List<Project> projectList(int studentId);
}
