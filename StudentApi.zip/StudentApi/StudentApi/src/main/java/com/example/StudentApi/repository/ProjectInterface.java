package com.example.StudentApi.repository;

import java.util.List;
import java.util.Optional;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.entity.Student;
import com.example.StudentApi.exceptions.ProjectException;

public interface ProjectInterface {

	int save(Project project) throws Exception;
	
	Optional<Project> findById(int projectId);
	
	List<Project> findAll();
	
	int updateProject(int projectId, Project project);

	List<Student> studentListBasedOnProject(int proejctId);

	int insertProjectStudent(int projectId, int studentId) throws ProjectException;
}
