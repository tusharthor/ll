package com.StudentAPI.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.StudentAPI.project.exception.ResourceNotFoundException;
import com.StudentAPI.project.model.StudentDetails;
import com.StudentAPI.project.repository.StudentRepository;

public class StudentsFindById {
	
	@Autowired
	private StudentRepository studentRepository;
	
	@GetMapping("/StudentsAPI/student/{Student_id}")
	
	public ResponseEntity<StudentDetails> getStudentDetailsById (@PathVariable(value= "Student_id") Long studentDetailsId)
	throws ResourceNotFoundException {
		StudentDetails studentDetails = studentRepository.findById(studentDetailsId)
		.orElseThrow(()-> new ResourceNotFoundException("Record not found for this id::" + studentDetailsId));
				return ResponseEntity.ok().body(studentDetails);
	}
	
	
	
	

}
