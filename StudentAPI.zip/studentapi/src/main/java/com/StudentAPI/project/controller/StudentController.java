package com.StudentAPI.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.StudentAPI.project.exception.ResourceNotFoundException;
import com.StudentAPI.project.model.StudentDetails;
import com.StudentAPI.project.repository.StudentRepository;

@RestController
@RequestMapping("/api/v1/")
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;
	
	//get student 
	@GetMapping("StudentsAPI/admin")
	
	public List<StudentDetails> getAllStudentDetails(){
		return this.studentRepository.findAll();
	}
	
	//get student by student id
	@GetMapping("/StudentsAPI/student/{Student_id}")
	
	public ResponseEntity<StudentDetails> getStudentDetailsById (@PathVariable(value= "Student_id") Long studentDetailsId)
	throws ResourceNotFoundException {
		StudentDetails studentDetails = studentRepository.findById(studentDetailsId)
		.orElseThrow(()-> new ResourceNotFoundException("Record not found for this id::" + studentDetailsId));
				return ResponseEntity.ok().body(studentDetails);
	}
	//save student
	
	@PostMapping("StudentsAPI/admin")

	public StudentDetails createStudentDetails(@RequestBody StudentDetails studentDetails) {
		return this.studentRepository.save(studentDetails);
	}
	
	//update student
	@PutMapping("StudentsAPI/admin/{Student_id}" )
	
	public ResponseEntity<StudentDetails> updateStudentDetails(@PathVariable(value="Student_id")Long studentDetailsId,
	@Valid @RequestBody StudentDetails StudentDetailsinfo) throws ResourceNotFoundException {
		StudentDetails studentDetails = studentRepository.findById(studentDetailsId)
				.orElseThrow(()-> new ResourceNotFoundException("Record not founded for this id::" + studentDetailsId));
		studentDetails.setFirst_Name(StudentDetailsinfo.getFirst_Name());
		studentDetails.setLast_Name(StudentDetailsinfo.getLast_Name());
		studentDetails.setMobile_no(StudentDetailsinfo.getMobile_no());
		studentDetails.setEmail_Id(StudentDetailsinfo.getEmail_Id());
		
		return ResponseEntity.ok(this.studentRepository.save(studentDetails));
		
	}
	
	
	//delete student
	
	@DeleteMapping ("StudentsAPI/admin/{Student_id}")

	public Map<String,Boolean> deleteStudentDetails(@PathVariable(value="Student_id")Long studentDetailsStudent_id) throws ResourceNotFoundException{
		
		StudentDetails studentDetails = studentRepository.findById(studentDetailsStudent_id)
				.orElseThrow(()-> new ResourceNotFoundException("Record not founded for this id::" + studentDetailsStudent_id));
		
		this.studentRepository.delete(studentDetails);
		
		Map<String, Boolean> response = new HashMap<>();
		
		response.put("deleted",Boolean.TRUE);
		
		return response;
				
	}

	
}
