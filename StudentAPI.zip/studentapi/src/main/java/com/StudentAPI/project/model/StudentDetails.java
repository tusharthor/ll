package com.StudentAPI.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name="admin")
@SecondaryTable(name="student",pkJoinColumns=@PrimaryKeyJoinColumn(name="Student_id",referencedColumnName="Student_id"))



public class StudentDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private long Student_id;
	
	
	@Column (name = "First_Name")
	private String First_Name;
	
	
	@Column (name = "Last_name")
	private String Last_Name;
	
	@Column (name = "Mobile_no")
	private String Mobile_no;
	
	@Column (name = "Email_Id")
	private String Email_Id;
	
	
	
	public StudentDetails() {
		super();
	}
	public StudentDetails(String first_Name, String last_Name, String mobile_no, String email_Id) {
		super();
		First_Name = first_Name;
		Last_Name = last_Name;
		Mobile_no = mobile_no;
		Email_Id = email_Id;
	}
	public long getStudent_id() {
		return Student_id;
	}
	public void setStudent_id(long student_id) {
		Student_id = student_id;
	}
	public String getFirst_Name() {
		return First_Name;
	}
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public String getMobile_no() {
		return Mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		Mobile_no = mobile_no;
	}
	public String getEmail_Id() {
		return Email_Id;
	}
	public void setEmail_Id(String email_Id) {
		Email_Id = email_Id;
	}
	
	
	
}
