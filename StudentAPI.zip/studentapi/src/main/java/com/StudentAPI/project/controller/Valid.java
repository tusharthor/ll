package com.StudentAPI.project.controller;

public @interface Valid {

}
